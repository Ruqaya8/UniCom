﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using test3.Data;
using test3.Models;

namespace test3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegestrationsController : ControllerBase
    {
        private readonly DataContext _context;

        public RegestrationsController(DataContext context)
        {
            _context = context;
        }

        // GET: api/Regestrations
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Regestration>>> GetRegestration()
        {
            return await _context.tblRegestration.ToListAsync();
        }

        // GET: api/Regestrations/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Regestration>> GetRegestration(int id)
        {
            var regestration = await _context.tblRegestration.FindAsync(id);

            if (regestration == null)
            {
                return NotFound();
            }

            return regestration;
        }

        // PUT: api/Regestrations/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutRegestration(int id, Regestration regestration)
        {
            if (id != regestration.RegestrationId)
            {
                return BadRequest();
            }

            _context.Entry(regestration).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RegestrationExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Regestrations
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Regestration>> PostRegestration(Regestration regestration)
        {
            _context.tblRegestration.Add(regestration);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetRegestration", new { id = regestration.RegestrationId }, regestration);
        }

        // DELETE: api/Regestrations/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteRegestration(int id)
        {
            var regestration = await _context.tblRegestration.FindAsync(id);
            if (regestration == null)
            {
                return NotFound();
            }

            _context.tblRegestration.Remove(regestration);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool RegestrationExists(int id)
        {
            return _context.tblRegestration.Any(e => e.RegestrationId == id);
        }

        [HttpPost("RegesterToEvent")]
        public async Task<IActionResult> RegesterToEvent(Regestration regestration)
        {
            try
            {
                await PostRegestration(regestration);
                return Ok(regestration);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet("GetAttendanceList")]
        public async Task<IActionResult> GetAttendanceList(Events events)
        {
            List<Student> AttendanceList = new List<Student>();
            MyEventAttendanceList myEventAttendanceList = new MyEventAttendanceList();

            try
            {
                var regestrations = await _context.tblRegestration.Where(r => r.EventId == events.EventId).ToListAsync();
                foreach (var item in regestrations)
                {
                    //Student student = _context.tblStudents.Where(s => s.StudentId == Item.StudentId).FirstOrDefault();
                    item.Student = await _context.tblStudents.FindAsync(item.StudentId);
                    if (item.Student != null)
                    {
                        AttendanceList.Add(item.Student);

                    }
                }
                myEventAttendanceList.AttendanceList = AttendanceList;
                if (String.IsNullOrEmpty(events.EventName))
                {
                    events.EventName = "Event";
                }
                myEventAttendanceList.EventName = events.EventName;
                myEventAttendanceList.OrganizerID = events.OrganizerID;
                myEventAttendanceList.EventId = events.EventId;
                return Ok(myEventAttendanceList);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }

        }
    }
}
