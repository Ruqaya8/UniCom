﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using test3.Data;
using test3.Models;
using test3.Controllers;

namespace test3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventsController : ControllerBase
    {
        private readonly DataContext _context;

        public EventsController(DataContext context)
        {
            _context = context;
        }

        // GET: api/Events1
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Events>>> GetEvents()
        {
            return await _context.tblEvents.ToListAsync();
        }

        // GET: api/Events1/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Events>> GetEvents(int id)
        {
            var events = await _context.tblEvents.FindAsync(id);

            if (events == null)
            {
                return NotFound();
            }

            return events;
        }

        // PUT: api/Events1/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutEvents(int id, Events events)
        {
            if (id != events.EventId)
            {
                return BadRequest();
            }

            _context.Entry(events).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EventsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Events1
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Events>> PostEvents(Events events)
        {
            _context.tblEvents.Add(events);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetEvents", new { id = events.EventId }, events);
        }

        // DELETE: api/Events1/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEvents(int id)
        {
            var events = await _context.tblEvents.FindAsync(id);
            if (events == null)
            {
                return NotFound();
            }

            _context.tblEvents.Remove(events);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool EventsExists(int id)
        {
            return _context.tblEvents.Any(e => e.EventId == id);
        }



        #region Internal Events functions

        //Used in Creat Event page 
        [HttpPost("CreateEvent")]
        public async Task<ActionResult<Events>> CreateEvent([FromBody] CreatEventRequest NewEventRequest)
        {
            
            int StudentID = Int32.Parse(NewEventRequest.StudentEmail.Substring(0, 9));
            NewEventRequest.NewEvent.Approve = false;
            NewEventRequest.NewEvent.ExternalEventAddress = "-";
            NewEventRequest.NewEvent.ExternalApprove = false;
            NewEventRequest.NewEvent.External = false;
            NewEventRequest.NewEvent.OrganizerID = StudentID;
            _context.tblEvents.Add(NewEventRequest.NewEvent);
            await _context.SaveChangesAsync();

            return Ok(NewEventRequest.NewEvent);
        }

        //Used in my Events list 
        [HttpGet("getMyEventsList")]
        public async Task<IActionResult> getMyEventsList(string email)
        {

            try
            {
                int OrganizerID = Int32.Parse(email.Substring(0, 9));
                var MyEventsList = await _context.tblEvents.Where(e => e.OrganizerID == OrganizerID && e.External == false).ToListAsync();
                if (MyEventsList.Count == 0)
                {
                    return NotFound();
                }
                return Ok(MyEventsList);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }


        }

        //used in Head Approved Events 
        [HttpGet("GetOrganizedEvents")]
        public async Task<IActionResult> GetOrganizedEvents()
        {
            //used
            try
            {
                var EventsList = await _context.tblEvents.Where(e => e.OrganizerID != 0 && e.External == false && e.Approve == false).ToListAsync();
                List<Events> OrganizedEvents = new List<Events>();
                if (EventsList != null)
                {
                    foreach (var item in EventsList)
                    {
                        DateTime convertedDate;
                        if (DateTime.TryParse(item.EventDate,out convertedDate))
                        {
                            if (item.Approve == false && checkEventDate(convertedDate))
                            {
                                OrganizedEvents.Add(item);
                            }
                        }
                    }
                    if (OrganizedEvents.Count != 0)
                    {
                        return Ok(OrganizedEvents);

                    }
                    else
                    {
                        return NotFound();
                    }
                }
                else
                {
                    return NotFound();
                }
            }
            catch
            {
                return BadRequest("Something Went Wrong :(");
            }
            


        }

        [HttpGet("GetUpcomingEvents")]
        public async Task<IActionResult> GetUpcomingEvents()
        {
            var EventsList = await _context.tblEvents.ToListAsync();
            List<Events> UpcomingEvents = new List<Events>();
            if (EventsList != null)
            {
                foreach (var item in EventsList)
                {
                    if (item.External == false)
                    {
                        DateTime convertedDate = DateTime.Parse(item.EventDate);
                        if (item.Approve == true && checkEventDate(convertedDate))
                        {
                            UpcomingEvents.Add(item);
                        }
                    }

                }
                if (UpcomingEvents.Count != 0)
                {
                    return Ok(UpcomingEvents);

                }
                else
                {
                    return Ok("No events");
                }
            }
            else
            {
                return NotFound();
            }


        }

        private static bool checkEventDate(DateTime EventDate)
        {
            //DateTime.Now.AddDays(-2)
            int result = DateTime.Compare(DateTime.Now, EventDate);

            if (result < 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //used in Head_Approved_Events
        [HttpPut("ApproveEvent")]
        public async Task<IActionResult> ApproveEvent([FromBody] Events events)
        {
            try
            {
                    events.Approve = true;
                    return await PutEvents(events.EventId, events);

            }
            catch
            {
                return BadRequest("Somnething Went wrong :(");
            }
           


        }
        #endregion

        //Used in external_Event
        #region External Events Functions
        [HttpPost("CreateExternalEvent")]
        public async Task<ActionResult<Events>> CreateExternalEvent([FromBody] CreatEventRequest externalEventRequest)
        {
            try
            {
                int StudentID = Int32.Parse(externalEventRequest.StudentEmail.Substring(0, 9));
                externalEventRequest.NewEvent.External = true;
                externalEventRequest.NewEvent.ExternalApprove = false;
                externalEventRequest.NewEvent.Approve = false;
                externalEventRequest.NewEvent.OrganizerID = StudentID;
                _context.tblEvents.Add(externalEventRequest.NewEvent);
                await _context.SaveChangesAsync();

                return Ok(externalEventRequest);
            }
            catch
            {
                return BadRequest();
            }

        }

        //Used in Head_Approve_external_events
        [HttpGet("GetExternalEventsList")]
        public async Task<IActionResult> GetExternalEventsList()
        {
            try
            {
                var EventsList = await _context.tblEvents.Where(e => e.OrganizerID != 0 && e.External == true && e.Approve == false && e.ExternalApprove == false).ToListAsync();
                if (EventsList.Count > 0)
                {
                    return Ok(EventsList);

                }
                else
                {
                    return NotFound();
                }
            }
            catch
            {
                return BadRequest( "Something Went Wrong :(" );
            }



        }

        //Used in Head_Approve_external_events
        [HttpPut("ApproveExternalEvent")]
        public async Task<IActionResult> ApproveExternalEvent(ApproveExternalEventRequest ApproveRequest)
        {
            try
            {
                if (ApproveRequest.MyEvent.External == true)
                {
                    ApproveRequest.MyEvent.ExternalApprove = true;
                    ApproveRequest.MyEvent.Approve = true;

                    string studentEmail = ApproveRequest.StudentId.ToString() + "@students.asu.edu.jo";
                    
                    var studentID = await GetStudentId(studentEmail.Trim());
                    if(studentID == 0)
                    {
                        return BadRequest("Something Went Wrong :(");
                    }
                    await PutEvents(ApproveRequest.MyEvent.EventId, ApproveRequest.MyEvent);

                    Attendance attendance = new Attendance();
                    attendance.EventId = ApproveRequest.MyEvent.EventId;
                    attendance.StudentId = studentID;

                    _context.tblAttendance.Add(attendance);
                    await _context.SaveChangesAsync();

                    return Ok();
                }
                else
                {
                    return BadRequest();
                }

            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }

            


        }
        private  async Task<int> GetStudentId(string  email)
        {
            try
            {
                int studentId = 0;
                Student student = _context.tblStudents.Where(s => s.Email.Equals(email)).FirstOrDefault();
                studentId = student.StudentId;
                return studentId;
            }catch
            {
                return 0;
            }
           
        }
        #endregion


    }
}
