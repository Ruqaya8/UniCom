﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace test3.Models
{
    public class SemesterEventsCard
    {
        //  * every card should include 1# EVENTs (- event name  -  event date -  points )
        //                              2# total points for every card.
        public int Totalpoints { get; set; }
        public string Semester { get; set; }
        public List<Events> Events { get; set; }

    }
    public class StudentEventsCard
    {
        public int TotalStudentPoints { get; set; }
        public List<SemesterEventsCard> studentEventsCards { get; set; }

    }
}
