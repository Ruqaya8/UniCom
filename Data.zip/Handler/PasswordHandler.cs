﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test3.Handler
{
    public class PasswordHandler
    {
        public static string Key = "asdfg48hb@@!!da??$44";

        public  static string EncryptPassword(string Password)
        {
            if (String.IsNullOrEmpty(Password)) return "";
            Password += Key;
            var PasswordBytes = Encoding.UTF8.GetBytes(Password);
            return Convert.ToBase64String(PasswordBytes);
        }

        public static string DecryptPassword(string Base64EncoddedPassword)
        {
            if (String.IsNullOrEmpty(Base64EncoddedPassword)) return "";
            var PasswordBytes = Convert.FromBase64String(Base64EncoddedPassword); 
            var Password = Encoding.UTF8.GetString(PasswordBytes);
            Password = Password.Substring(0, Password.Length - Key.Length);
            return Password;
        }
    }
}
