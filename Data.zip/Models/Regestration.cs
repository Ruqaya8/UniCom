﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace test3.Models
{
    public class Regestration
    {
        [Key]
        public int RegestrationId { get; set; }
        public int StudentId { get; set; }
        public int EventId { get; set; }
        public Student Student { get; set; }
        public Events Event { get; set; }
    }
    public class MyEventAttendanceList
    {
        public int EventId { get; set; }
        public string EventName { get; set; }
        public int OrganizerID { get; set; }
        public List<Student> AttendanceList { get; set; }
    }
}
