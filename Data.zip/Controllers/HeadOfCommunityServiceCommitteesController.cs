﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using test3.Data;
using test3.Handler;
using test3.Models;

namespace test3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HeadOfCommunityServiceCommitteesController : ControllerBase
    {
        private readonly DataContext _context;

        public HeadOfCommunityServiceCommitteesController(DataContext context)
        {
            _context = context;
        }

        // GET: api/HeadOfCommunityServiceCommittees
        [HttpGet]
        public async Task<ActionResult<IEnumerable<HeadOfCommunityServiceCommittee>>> GetHeadOfCommunityServiceCommittee()
        {
            return await _context.tblHeadOfCommunityServiceCommittees.ToListAsync();
        }

        // GET: api/HeadOfCommunityServiceCommittees/5
        [HttpGet("{id}")]
        public async Task<ActionResult<HeadOfCommunityServiceCommittee>> GetHeadOfCommunityServiceCommittee(int id)
        {
            var headOfCommunityServiceCommittee = await _context.tblHeadOfCommunityServiceCommittees.FindAsync(id);

            if (headOfCommunityServiceCommittee == null)
            {
                return NotFound();
            }

            return headOfCommunityServiceCommittee;
        }

        // PUT: api/HeadOfCommunityServiceCommittees/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutHeadOfCommunityServiceCommittee(int id, HeadOfCommunityServiceCommittee headOfCommunityServiceCommittee)
        {
            if (id != headOfCommunityServiceCommittee.HeadOfCommunityServiceCommitteeId)
            {
                return BadRequest();
            }

            _context.Entry(headOfCommunityServiceCommittee).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!HeadOfCommunityServiceCommitteeExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/HeadOfCommunityServiceCommittees
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<HeadOfCommunityServiceCommittee>> PostHeadOfCommunityServiceCommittee(HeadOfCommunityServiceCommittee headOfCommunityServiceCommittee)
        {
            _context.tblHeadOfCommunityServiceCommittees.Add(headOfCommunityServiceCommittee);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetHeadOfCommunityServiceCommittee", new { id = headOfCommunityServiceCommittee.HeadOfCommunityServiceCommitteeId }, headOfCommunityServiceCommittee);
        }

        // DELETE: api/HeadOfCommunityServiceCommittees/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteHeadOfCommunityServiceCommittee(int id)
        {
            var headOfCommunityServiceCommittee = await _context.tblHeadOfCommunityServiceCommittees.FindAsync(id);
            if (headOfCommunityServiceCommittee == null)
            {
                return NotFound();
            }

            _context.tblHeadOfCommunityServiceCommittees.Remove(headOfCommunityServiceCommittee);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool HeadOfCommunityServiceCommitteeExists(int id)
        {
            return _context.tblHeadOfCommunityServiceCommittees.Any(e => e.HeadOfCommunityServiceCommitteeId == id);
        }
        [HttpPost("LoginAsHead")]
        public async Task<ActionResult<HeadOfCommunityServiceCommittee>> LoginAsHead(HeadLogin h)
        {

            var Head = await _context.tblHeadOfCommunityServiceCommittees.Where(Head => Head.Email.ToLower().Contains(h.Email.ToLower())).FirstAsync();

            string HeadPassword = PasswordHandler.DecryptPassword(Head.Password);

            if (Head == null)
            {
                return NotFound();
            }
            else if (HeadPassword.Equals(h.Password))
            {
                return Ok(Head);
            }
            else
            {
                return BadRequest();
            }


        }

        [HttpPut("EncryptHeadsPasswords")]
        public async Task<IActionResult> EncryptHeadsPasswords()
        {
            try
            {
                var HeadList = await _context.tblHeadOfCommunityServiceCommittees.OrderBy(h => h.HeadOfCommunityServiceCommitteeId).ToListAsync();
                foreach (var item in HeadList)
                {
                    item.Password = PasswordHandler.EncryptPassword(item.Password);
                    await PutHeadOfCommunityServiceCommittee(item.HeadOfCommunityServiceCommitteeId, item);
                }
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }

        }

    }
}
