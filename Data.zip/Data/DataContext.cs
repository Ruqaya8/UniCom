﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using test3.Models;

namespace test3.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options)
            : base(options)
        {
        }

        public DbSet<Student> tblStudents { get; set; }


        public DbSet<HeadOfCommunityServiceCommittee> tblHeadOfCommunityServiceCommittees { get; set; }


        public DbSet<Attendance> tblAttendance { get; set; }
        public DbSet<Events> tblEvents { get; set; }
        public DbSet<Regestration> tblRegestration { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Student>().HasData(
                new Student { StudentId = 1, Name = "Farah Eid", Email = "201810713@students.asu.edu.jo", Password = "Farah123", PhoneNumber = "0777341106", Major = "ComputerScience" },
                new Student { StudentId = 2, Name = "Rawan Hussein", Email = "201820246@students.asu.edu.jo", Password = "Rawan123", PhoneNumber = "0792127392", Major = "SoftwareEngineer" },
                new Student { StudentId = 3, Name = "Ruqaya Qassia", Email = "202020303@students.asu.edu.jo", Password = "Ruqaya123", PhoneNumber = "0786939687", Major = "ComputerScience" }

                );


            modelBuilder.Entity<HeadOfCommunityServiceCommittee>().HasData(
                new HeadOfCommunityServiceCommittee { HeadOfCommunityServiceCommitteeId = 1, Name = "Yosra odeh", Email = "YosraOdeh@students.asu.edu.jo", Password = "Yosra123" }
              );


            modelBuilder.Entity<Events>().HasData(
                new Events { EventId = 1, EventName = "Excel WorkShop", EventDate = "3/11/2018", Points = 1, Approve = true, Semester="20181" ,status="participant" },
                new Events { EventId = 2, EventName = "Young Translator Contest", EventDate = "12/3/2019", Points = 1, Approve = true , Semester = "20182" },
                new Events { EventId = 3, EventName = "JCPC", EventDate = "8/11/2019", Points = 2, Approve = true , Semester="20191"},
                new Events { EventId = 4, EventName = "Role Day", EventDate = "12/5/2019", Points = 1, Approve = true, Semester = "20182" },
                new Events { EventId = 5, EventName = "CTF", EventDate = "3/5/2020", Points = 1, Approve = true, Semester = "20202" },
                new Events { EventId = 6, EventName = "UI/UX", EventDate = "12/12/2020", Points = 1, Approve = true, Semester = "20201" },
                new Events { EventId = 7, EventName = "ACC7", EventDate = "12/5/2021", Points = 2, Approve = true, Semester = "20212" },
                new Events { EventId = 8, EventName = "Womans Day", EventDate = "8/2/2021", Points = 1, Approve = true, Semester = "20211" },

                new Events { EventId = 10, EventName = "Rally Al-Arab", EventDate = "12/1/2019", Points = 2, Approve = true, Semester = "20191" },
                new Events { EventId = 11, EventName = "ACC", EventDate = "8/4/2019", Points = 2, Approve = true, Semester = "20192" },
                new Events { EventId = 12, EventName = "CTF", EventDate = "12/11/2020", Points = 1, Approve = true, Semester = "20201" },
                new Events { EventId = 13, EventName = "UI/UX", EventDate = "9/5/2020", Points = 2, Approve = true, Semester = "20202" },
                new Events { EventId = 14, EventName = "Zain Al-Mubadara", EventDate = "10/12/2021", Points = 1, Approve = true, Semester = "20211" },
                new Events { EventId = 15, EventName = "Amazon Teckathon", EventDate = "8/6/2021", Points = 2, Approve = true, Semester = "20212" },

                new Events { EventId = 17, EventName = "IEEE", EventDate = "5/5/2021", Points = 2, Approve = true, Semester = "20202" },
                new Events { EventId = 18, EventName = "Womans Day", EventDate = "6/3/2021", Points = 2, Approve = true, Semester = "20201" }

           );
            modelBuilder.Entity<Attendance>().HasData(
                
                new Attendance { AttendanceId = 1, StudentId = 1, EventId = 1 },
                new Attendance { AttendanceId = 2, StudentId = 1, EventId = 2 },
                new Attendance { AttendanceId = 3, StudentId = 1, EventId = 3 },
                new Attendance { AttendanceId = 4, StudentId = 1, EventId = 4 },
                new Attendance { AttendanceId = 5, StudentId = 1, EventId = 5 },
                new Attendance { AttendanceId = 6, StudentId = 1, EventId = 6 },
                new Attendance { AttendanceId = 7, StudentId = 1, EventId = 7 },
                new Attendance { AttendanceId = 8, StudentId = 1, EventId = 8 },

                new Attendance { AttendanceId = 10, StudentId = 2, EventId = 10 },
                new Attendance { AttendanceId = 11, StudentId = 2, EventId = 11 },
                new Attendance { AttendanceId = 12, StudentId = 2, EventId = 12 },
                new Attendance { AttendanceId = 13, StudentId = 2, EventId = 13 },
                new Attendance { AttendanceId = 14, StudentId = 2, EventId = 14 },
                new Attendance { AttendanceId = 15, StudentId = 2, EventId = 15 },

                new Attendance { AttendanceId = 17, StudentId = 3, EventId = 17 },
                new Attendance { AttendanceId = 18, StudentId = 3, EventId = 18 }
           );

        }









    }
}
