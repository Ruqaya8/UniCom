﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using test3.Data;
using test3.Models;
using test3.Handler;

namespace test3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentsController : ControllerBase
    {
        private readonly DataContext _context;
        //private IConfiguration _config;

        public StudentsController(DataContext context/*, IConfiguration config*/)
        {
            _context = context;
            //_config = config;
        }


        // GET: api/Students
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Student>>> GetStudent()
        {
            return await _context.tblStudents.ToListAsync();
        }

        // GET: api/Students/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Student>> GetStudent(int id)
        {
            var student = await _context.tblStudents.FindAsync(id);

            if (student == null)
            {
                return NotFound();
            }

            return student;
        }

        // PUT: api/Students/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutStudent(int id, Student student)
        {
            if (id != student.StudentId)
            {
                return BadRequest();
            }

            _context.Entry(student).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!StudentExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Students
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Student>> PostStudent(Student student)
        {
            _context.tblStudents.Add(student);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetStudent", new { id = student.StudentId }, student);
        }

        // DELETE: api/Students/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteStudent(int id)
        {
            var student = await _context.tblStudents.FindAsync(id);
            if (student == null)
            {
                return NotFound();
            }

            _context.tblStudents.Remove(student);
            await _context.SaveChangesAsync();

            return NoContent();
        }
        private bool StudentExists(int id)
        {
            return _context.tblStudents.Any(e => e.StudentId == id);
        }
        //[HttpPut("SaveImage")]
        //public async Task<ActionResult> SaveImage([FromBody] Student student)
        //{

        //    var s = await _context.tblStudents.FindAsync(student.StudentId);

        //    if (s == null)
        //    {
        //        return NotFound();
        //    }

        //    s.image = student.image;

        //    try
        //    {
        //        await PutStudent(s.StudentId, s);
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!StudentExists(s.StudentId))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return Ok();

        //}
        //[HttpGet("GetImage")]
        //public async Task<ActionResult<IEnumerable<Student>>> GetImage(int id)
        //{
        //    var student = await GetStudent(id);
        //    return Ok(student.Value.image);

        //}

        //[AllowAnonymous]
        //[HttpPost("Login")]
        //public async  Task<IActionResult> Login([FromBody] StudentLogin userLogin)
        //{
        //    var student =  await Authenticate(userLogin);
        //    if(student != null)
        //    {
        //        var token = Generate(student);
        //        return Ok(token);
        //    }
        //    return NotFound();
        //}

        //private object Generate(Student student)
        //{
        //    var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
        //    var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

        //    var claims = new[]
        //    {
        //        new Claim(ClaimTypes.NameIdentifier,student.Name),
        //          new Claim(ClaimTypes.Email,student.Email),

        //    };
        //    var token = new JwtSecurityToken(_config["Jwt:Issure"],
        //       _config["Jwt:Audience"],
        //       claims,
        //       expires: DateTime.Now.AddMinutes(15),
        //       signingCredentials: credentials);
        //    return new JwtSecurityTokenHandler().WriteToken(token);
        //}

        //private async  Task<Student> Authenticate(StudentLogin userLogin)
        //{
        //    var s = await _context.tblStudents.Where(s => s.Email == userLogin.Email && s.Password ==userLogin.Password).FirstOrDefaultAsync();
        //    if (s != null)
        //    {
        //        return s;
        //    }
        //    return null;
        //}  


        [HttpPost("LoginAsStudents")]
        [Authorize]
        public async Task<ActionResult<Student>> LoginAsStudents(StudentLogin s)
        {

            var student = await _context.tblStudents.Where(student => student.Email.ToLower().Replace(" ", "").Contains(s.Email.ToLower().Replace(" ", ""))).FirstAsync();

            string studentPassword = PasswordHandler.DecryptPassword(student.Password);
            if (student == null)
            {
                return NotFound();
            }else if (studentPassword.Equals(s.Password))
            {
                return Ok(student);
            }
            else
            {
                return BadRequest();
            }
            


        }
   
        //not Used
        [HttpGet("GetProfile")]
        [AllowAnonymous]
        public async Task<IActionResult> GetProfile(string email)
        {
            var student = await _context.tblStudents.Where(e => e.Email.Equals(email)).FirstOrDefaultAsync();

            if (student == null)
            {
                return NotFound();
            }


            return Ok(student);
        }

        //Used In Road Map
        [HttpGet("GetRoadMap")]
        [AllowAnonymous]
        public async Task<IActionResult> GetRoadMap(string email)
        {
            /*TO DO:
             * we need to find the number of cards(semesters) the student has depending on the email. ###done### 
             * every card should include 1# EVENTs (- event name  -  event date -  points ) 2# total points for every card.
             * add at the end the Balance of each student
             * ***********************************************************************
             * 
             * 
             * email example : 201810713@students.asu.edu.jo
             * every year should include 3semesters.
             * every semester should include 2 points or 1 or 0
             * ********************** 
             * think about the logic for the rest of this API 
             * modify the event table and model/(add points field)#####done#####
             * 
             * Event = _context.tblEvents.Where(e=> e.EventId == 1).FirstOrDefault() , 
             * Student = _context.tblStudents.Where(s => s.StudentId == 1).FirstOrDefault()
             */
            int TotalPoints = 0;
            //int SemesterPoints = 0;
            List<SemesterEventsCard> CardsList = new List<SemesterEventsCard>();

            try
            {
                string EnterSemester = email.Substring(0, 5);
                int numberofSemesters = NumOfSemesters(EnterSemester);

                var Attendances = await _context.tblAttendance.Where(a => a.Student.Email.Equals(email)).ToListAsync();
                if (Attendances != null)
                {
                    /*
                     1# we should start events from the date he started until now
                     2# how to calculate the total points of all semesters
                     3# what should we return to the frnt-end as JSON
                     */
                    var SemesterCurrentValue = EnterSemester;
                    for (int i = 0; i < numberofSemesters; i++)
                    {

                        if (i != 0)
                        {
                            SemesterCurrentValue = IncrementSemester(SemesterCurrentValue);
                        }
                        SemesterEventsCard MyCard = new SemesterEventsCard();
                        List<Events> semesterEvents = new List<Events>();
                        foreach (var item in Attendances)
                        {
                            item.Event = await _context.tblEvents.FindAsync(item.EventId);
                            item.Student = await _context.tblStudents.FindAsync(item.StudentId);
                            MyCard.Semester = SemesterCurrentValue;
                            if (item.Event != null)
                            {
                                //var eventSemester = EventSemester(item.Event.EventDate.Month, item.Event.EventDate.Year);
                                //var eventSemester = item.Event.Semester;
                                if (SemesterCurrentValue == item.Event.Semester)
                                {
                                    semesterEvents.Add(item.Event);
                                    MyCard.Totalpoints += item.Event.Points;
                                    MyCard.Events = semesterEvents;
                                }
                            }
                        }
                        CardsList.Add(MyCard);
                    }

                    foreach (var item in CardsList)
                    {
                        TotalPoints += item.Totalpoints;
                    }
                    StudentEventsCard studentCards = new StudentEventsCard();
                    studentCards.TotalStudentPoints = TotalPoints; // points for all semesters
                    studentCards.studentEventsCards = CardsList; // list of event cards (each card contains semester events and points)
                    return Ok(studentCards);
                }
                else
                {
                    return NotFound();
                }
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
        }

        private string IncrementSemester(string EnterSemester)
        {
            int enterYear = int.Parse(EnterSemester.Substring(0, 4)); //20181
            int enterSemester = int.Parse(EnterSemester.Substring(4, 1));
            if (enterSemester > 1)
            {
                enterYear += 1;
                enterSemester = 1;
            }
            else
            {
                enterSemester = 2;
            }
            return enterYear.ToString() + enterSemester.ToString();

        }
        private string EventSemester(int month, int Year)
        {
            string sem = "";
            if (month >= 2 && month <= 9)
            {
                sem = "2";
                Year--;
            }
            else if ((month >= 10 && month <= 12))
            {
                sem = "1";
            }
            else
            {
                sem = "1";
                Year--;
            }

            string semNUmber = Year.ToString() + sem;
            return semNUmber;
        }
        private int NumOfSemesters(string enterSemester)
        {
            int YearNow = DateTime.Now.Year;
            int MonthNow = DateTime.Now.Month;
            int numberOfYears = YearNow - int.Parse(enterSemester.Substring(0, 4));
            int numOfSemestersG = numberOfYears * 2;
            if (MonthNow == 1 )
            {
                numOfSemestersG--;
            }
            //if (MonthNow >= 2 && MonthNow <= 9)
            //{
            //    numOfSemestersG = numberOfYears * 2;
            //}
            //else if(MonthNow >= 10 && MonthNow <= 1)
            //{
            //    numOfSemestersG = numberOfYears * 2;
            //}

            string semesterNum = enterSemester.Substring(4, 1);

            if (semesterNum.Equals("1"))
            {
                return numOfSemestersG;
            }
            else
            {
                return numOfSemestersG - 1;
            }

        }


        //only use this api to encrypt passwords when create database for the frst time 
        [HttpPut("EncryptStudentsPasswords")]
        public async Task<IActionResult> EncryptStudentsPasswords()
        {
            try
            {
                var StudentsList = await _context.tblStudents.OrderBy(s => s.StudentId).ToListAsync();
                foreach (var item in StudentsList)
                {
                    item.Password = PasswordHandler.EncryptPassword(item.Password);
                    await PutStudent(item.StudentId, item);
                }
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }

        }

    }
}
