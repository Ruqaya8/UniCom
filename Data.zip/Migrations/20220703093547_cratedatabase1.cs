﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace test3.Migrations
{
    public partial class cratedatabase1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "status",
                table: "tblEvents",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.UpdateData(
                table: "tblEvents",
                keyColumn: "EventId",
                keyValue: 1,
                column: "status",
                value: "participant");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "status",
                table: "tblEvents");
        }
    }
}
