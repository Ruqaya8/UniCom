﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace test3.Models
{
    public class Events
    {
        [Key]
        public int EventId { get; set; }
        public string EventName { get; set; }
        public string EventDate { get; set; }
        public int Points { get; set; }
        public string SupervisorName { get; set; }
        public string EventPurpose { get; set; }
        public string Semester { get; set; }
        public string Note { get; set; }
        public bool Approve { get; set; } = false;
        public string ExternalEventAddress { get; set; }
        public bool ExternalApprove { get; set; } = false;
        public bool External { get; set; }
        public string CertifcateImage { get; set; }
        public int OrganizerID { get; set; }
        public string status { get; set; }

    }
    public class ApproveExternalEventRequest
    {
        public Events MyEvent { get; set; }
        public int StudentId { get; set; }
    }
    public class CreatEventRequest
    {
        public Events NewEvent { get; set; }
        public string StudentEmail { get; set; }
    }
}
