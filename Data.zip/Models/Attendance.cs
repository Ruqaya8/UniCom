﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace test3.Models
{
    public class Attendance
    {
        [Key]
        public int AttendanceId { get; set; }
        public int StudentId { get; set; }
        public int EventId { get; set; }
        public Student Student { get; set; }
        public Events Event { get; set; }

    }
    public class SaveAttendancesRequest
    {
        public int EventI_D { get; set; }
        public List<Student> StudentsList { get; set; }
    }
}
