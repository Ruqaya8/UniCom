﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace test3.Migrations
{
    public partial class Createdatebase : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "tblEvents",
                columns: table => new
                {
                    EventId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EventName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EventDate = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Points = table.Column<int>(type: "int", nullable: false),
                    SupervisorName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EventPurpose = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Semester = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Note = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Approve = table.Column<bool>(type: "bit", nullable: false),
                    ExternalEventAddress = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ExternalApprove = table.Column<bool>(type: "bit", nullable: false),
                    External = table.Column<bool>(type: "bit", nullable: false),
                    CertifcateImage = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OrganizerID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblEvents", x => x.EventId);
                });

            migrationBuilder.CreateTable(
                name: "tblHeadOfCommunityServiceCommittees",
                columns: table => new
                {
                    HeadOfCommunityServiceCommitteeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblHeadOfCommunityServiceCommittees", x => x.HeadOfCommunityServiceCommitteeId);
                });

            migrationBuilder.CreateTable(
                name: "tblStudents",
                columns: table => new
                {
                    StudentId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Major = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblStudents", x => x.StudentId);
                });

            migrationBuilder.CreateTable(
                name: "tblAttendance",
                columns: table => new
                {
                    AttendanceId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StudentId = table.Column<int>(type: "int", nullable: false),
                    EventId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblAttendance", x => x.AttendanceId);
                    table.ForeignKey(
                        name: "FK_tblAttendance_tblEvents_EventId",
                        column: x => x.EventId,
                        principalTable: "tblEvents",
                        principalColumn: "EventId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_tblAttendance_tblStudents_StudentId",
                        column: x => x.StudentId,
                        principalTable: "tblStudents",
                        principalColumn: "StudentId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "tblRegestration",
                columns: table => new
                {
                    RegestrationId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StudentId = table.Column<int>(type: "int", nullable: false),
                    EventId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblRegestration", x => x.RegestrationId);
                    table.ForeignKey(
                        name: "FK_tblRegestration_tblEvents_EventId",
                        column: x => x.EventId,
                        principalTable: "tblEvents",
                        principalColumn: "EventId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_tblRegestration_tblStudents_StudentId",
                        column: x => x.StudentId,
                        principalTable: "tblStudents",
                        principalColumn: "StudentId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "tblEvents",
                columns: new[] { "EventId", "Approve", "CertifcateImage", "EventDate", "EventName", "EventPurpose", "External", "ExternalApprove", "ExternalEventAddress", "Note", "OrganizerID", "Points", "Semester", "SupervisorName" },
                values: new object[,]
                {
                    { 1, true, null, "3/11/2018", "Excel WorkShop", null, false, false, null, null, 0, 1, "20181", null },
                    { 18, true, null, "6/3/2021", "Womans Day", null, false, false, null, null, 0, 2, "20201", null },
                    { 17, true, null, "5/5/2021", "IEEE", null, false, false, null, null, 0, 2, "20202", null },
                    { 15, true, null, "8/6/2021", "Amazon Teckathon", null, false, false, null, null, 0, 2, "20212", null },
                    { 14, true, null, "10/12/2021", "Zain Al-Mubadara", null, false, false, null, null, 0, 1, "20211", null },
                    { 13, true, null, "9/5/2020", "UI/UX", null, false, false, null, null, 0, 2, "20202", null },
                    { 12, true, null, "12/11/2020", "CTF", null, false, false, null, null, 0, 1, "20201", null },
                    { 10, true, null, "12/1/2019", "Rally Al-Arab", null, false, false, null, null, 0, 2, "20191", null },
                    { 11, true, null, "8/4/2019", "ACC", null, false, false, null, null, 0, 2, "20192", null },
                    { 7, true, null, "12/5/2021", "ACC7", null, false, false, null, null, 0, 2, "20212", null },
                    { 6, true, null, "12/12/2020", "UI/UX", null, false, false, null, null, 0, 1, "20201", null },
                    { 5, true, null, "3/5/2020", "CTF", null, false, false, null, null, 0, 1, "20202", null },
                    { 4, true, null, "12/5/2019", "Role Day", null, false, false, null, null, 0, 1, "20182", null },
                    { 3, true, null, "8/11/2019", "JCPC", null, false, false, null, null, 0, 2, "20191", null },
                    { 2, true, null, "12/3/2019", "Young Translator Contest", null, false, false, null, null, 0, 1, "20182", null },
                    { 8, true, null, "8/2/2021", "Womans Day", null, false, false, null, null, 0, 1, "20211", null }
                });

            migrationBuilder.InsertData(
                table: "tblHeadOfCommunityServiceCommittees",
                columns: new[] { "HeadOfCommunityServiceCommitteeId", "Email", "Name", "Password" },
                values: new object[] { 1, "YosraOdeh@students.asu.edu.jo", "Yosra odeh", "Yosra123" });

            migrationBuilder.InsertData(
                table: "tblStudents",
                columns: new[] { "StudentId", "Email", "Major", "Name", "Password", "PhoneNumber" },
                values: new object[,]
                {
                    { 2, "201820246@students.asu.edu.jo", "SoftwareEngineer", "Rawan Hussein", "Rawan123", "0792127392" },
                    { 1, "201810713@students.asu.edu.jo", "ComputerScience", "Farah Eid", "Farah123", "0777341106" },
                    { 3, "202020303@students.asu.edu.jo", "ComputerScience", "Ruqaya Qassia", "Ruqaya123", "0786939687" }
                });

            migrationBuilder.InsertData(
                table: "tblAttendance",
                columns: new[] { "AttendanceId", "EventId", "StudentId" },
                values: new object[,]
                {
                    { 1, 1, 1 },
                    { 2, 2, 1 },
                    { 3, 3, 1 },
                    { 4, 4, 1 },
                    { 5, 5, 1 },
                    { 6, 6, 1 },
                    { 7, 7, 1 },
                    { 8, 8, 1 },
                    { 10, 10, 2 },
                    { 11, 11, 2 },
                    { 12, 12, 2 },
                    { 13, 13, 2 },
                    { 14, 14, 2 },
                    { 15, 15, 2 },
                    { 17, 17, 3 },
                    { 18, 18, 3 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_tblAttendance_EventId",
                table: "tblAttendance",
                column: "EventId");

            migrationBuilder.CreateIndex(
                name: "IX_tblAttendance_StudentId",
                table: "tblAttendance",
                column: "StudentId");

            migrationBuilder.CreateIndex(
                name: "IX_tblRegestration_EventId",
                table: "tblRegestration",
                column: "EventId");

            migrationBuilder.CreateIndex(
                name: "IX_tblRegestration_StudentId",
                table: "tblRegestration",
                column: "StudentId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tblAttendance");

            migrationBuilder.DropTable(
                name: "tblHeadOfCommunityServiceCommittees");

            migrationBuilder.DropTable(
                name: "tblRegestration");

            migrationBuilder.DropTable(
                name: "tblEvents");

            migrationBuilder.DropTable(
                name: "tblStudents");
        }
    }
}
